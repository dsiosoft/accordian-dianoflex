// JavaScript Document
$(function() {
  const cssClasses = [
    'rangeslider--is-lowest-value',
    'rangeslider--is-highest-value'
  ];
  
  $('input[type=range]')
    .rangeslider({
      polyfill: false
    })
    .on('input', function() {
      const fraction = (this.value - this.min) / (this.max - this.min);
      if (fraction === 0) {
        this.nextSibling.classList.add(cssClasses[0]);
      } else if (fraction === 1) {
        this.nextSibling.classList.add(cssClasses[1]);
      } else {
        this.nextSibling.classList.remove(cssClasses);
      }
    });
});

		/*var slider = document.getElementsByClassName("myRange")[0];
			var output = document.getElementsByClassName("range-bar")[0];
			output.innerHTML = slider.value+'%';
			slider.oninput = function(){
			  output.innerHTML = this.value+'%';
			}*/
	
$(document).ready(function() {
               /*--------- toggle Menu     ---------*/

	   $('.accordion-tab ul li a').click(function(e) {
		 
		//var datatab = $(this).attr('data-tab');
		//alert(datatab);
		var tab_id = $(this).parent('li').addClass('current').data('tab');
		$(this).siblings().removeClass('current');
		$('#'+ tab_id + ' .accordionjs-select').trigger('click');
		//return false;

		$('ul#accordion li.colapse').each(function(index, element) {
		   var dataid = $(this).attr('id');
			
			if(tab_id == dataid){
				$(this).toggleClass('selected');
				$(this).siblings().removeClass('selected');
			}
		});
    });
	
	
	
	$('ul#accordion li.colapse').click(function(e) {
		var at = $(this).attr('id');
		$('.accordion-tab ul li').each(function(index, element) {
		   var tab = $(this).attr('data-tab');
			if(at == tab){
				$(this).toggleClass('current');
				$(this).siblings().removeClass('current');
			}
		});
    });
	
	$('#accordion li').click(function(){
		if (document.getElementsByClassName('selected')) {
		   $(this).toggleClass('selected');
		} else {
		  $(this).removeClass('selected');  
		}
	});
	
	$('.accordion-tab>ul li').click(function(){
		var nav_id = $(this).attr('data-tab');
		$('.accordion-tab>ul li').removeClass('current');
		$(this).addClass('current');
		$('#Step_1'+nav_id).find('li').trigger('click');
		return false;
	});
	
	
	$("#accordion li").on( "click", function( event ) {
		var step_id = $(this).attr('id');
		$('#accordion li').removeClass('current');		
		var aa = $('#accordion li[data-tab='+step_id+']').addClass('current');
	});
});
	$(document).ready(function(){
		 var current_id = 0;
			$('.add_new').click(function(){
				nextElement($('#Meal_00'));
			})
			 function nextElement(element){
				var newElement = element.clone(true,true);
				var id = current_id+1;
				current_id = id;
				if(id <10)id = "0"+id;
				newElement.attr("id",element.attr("id").split("_")[0]+"_"+id);
				var field = $('.temp_data', newElement).attr("id");
				$('.temp_data', newElement).attr("id", field.split("_")[0]+"_"+id );
				newElement.appendTo($("#tp"));
			}
	});

$(document).ready(function() {
	
	var slider = document.getElementsByClassName("myRange")[0];
	
	var output = document.getElementsByClassName("range-bar")[0];
	
	output.innerHTML = slider.value+'%';
	
	slider.oninput = function() {
	  output.innerHTML = this.value+'%';
	}

			
/*
	var slider1 = document.getElementById("myRange1");
	
	var output1 = document.getElementById("range-bar1");
	
	output1.innerHTML = slider1.value+'%';
	
	slider1.oninput = function() {
	  output1.innerHTML = this.value+'%';
	}

	var slider2 = document.getElementById("myRange2");
	
	var output2 = document.getElementById("range-bar2");
	
	output2.innerHTML = slider2.value+'%';
	
	slider2.oninput = function() {
	  output2.innerHTML = this.value+'%';
	}

	var slider3 = document.getElementById("myRange3");
	
	var output3 = document.getElementById("range-bar3");
	
	output3.innerHTML = slider3.value+'%';
	
	slider3.oninput = function() {
	  output3.innerHTML = this.value+'%';
	}

	var slider4 = document.getElementById("myRange4");
	
	var output4 = document.getElementById("range-bar4");
	
	
	output4.innerHTML = slider4.value+'%';
	
	slider4.oninput = function() {
	  output4.innerHTML = this.value+'%';
	}
	
	var slider5 = document.getElementById("range_total_value");
	
	var output5 = document.getElementById("Progressbar-value");
	slider5.oninput = function() {
	  output5.innerHTML = this.value+'%';
	}
	*/
	$('.mixit').click(function(){
		
     	var a = parseInt($('.myRange').val());
		//var b = parseInt($('#myRange1').val());
		//var c = parseInt($('#myRange2').val());
		//var d = parseInt($('#myRange3').val());
		//var e = parseInt($('#myRange4').val());
		
		console.log("mixit "+a,b,c,d,e);
		var result = (a+b+c+d+e)/5;
		document.getElementById('range_total_value').innerHTML = result;
		document.getElementById('Progressbar-value').innerHTML = result+'%';
		$('#Progressbar .rangeslider .rangeslider__fill ').css('width',result+'%');
		return false;
		
		//alert(result);
	});
	
		//output5.innerHTML = slider5.value+'%';
		
	$('#reset-form a').click(function(){
	 		var reset_value = document.getElementById("myRange4").value;
			//$("#myRange4").attr('value', 0);
			$(".rangeslider .rangeslider__fill").css('width', '10%')
			$('.rangeslider .rangeslider__handle').css('left','10px');
		    $('.percent p span').empty().text("10%");
		    $('#Progressbar-value').empty().text("10%");
			$('.range input').attr('value', 0);
			console.log("reset");
     		return false;
	});
	/*Image picker*/
		$('#accordionjs-page-0 .display1 .thumbnail1').click(function(){
			$(this).addClass('selected');
			$(this).siblings().removeClass('selected');
		});
		
		
		$(document).ready(function(){
				$('.thumbnail1 img').click(function(){
					var trial = $('.thumbnail1 img').attr("src");
					console.log(trial);
					$(".paste").attr("src", trial);
				});
		});
});
/*$(document).ready(function(e) {
	$( "#thumbnail .thumbnail .fa-close" ).on( "click", function() {
   
	var replacediv = $("div.replace").replaceWith(function() {
        return $( this ).contents();
    }); 
		$('#color-mix .color-sel').append($container.attr( "class" ));
		//$('#color-mix .color-sel').removeClass('replaca1');
		console.log();
	});
			 
});*/